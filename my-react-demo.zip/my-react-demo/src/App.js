import logo from './logo.svg';
import './App.css';
import './CSS-Component/Cards.css'
import Header from './component/Header'
import ArrowFutn from './component/ArrowFutn'
import Website from './component/Day8-Routing/Website';
import 'bootstrap/dist/css/bootstrap.min.css' 

function App() {
  return (
    <div className="App">
      {/* <h1>Welcome To The React-JS Page</h1>
      <Header/> 
      <ArrowFutn/> */}

      
      <Website/>
    </div>
  );
}

export default App;
