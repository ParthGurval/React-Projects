const ArrowFutn = () => {

    return(

        <div>
            <h1 
                style={{
                            color:"red", 
                            fontSize: "28px"
                        }}>
                This is Head using Arrow Function
            </h1>

            <h2 
                style={{
                            color:"green", 
                            fontSize: "24px"
                        }}>This is Heading Two
            </h2>
        </div>
    )
        
}

export default ArrowFutn;