import React from 'react'

const Services = () => {
  return (
    <div>
      <p>This is Service Page</p>
    </div>
  )
}

export default Services
