import React from 'react'

const ContactUs = () => {
  return (
    <div>
      <p>This is Contact Us Page</p>
    </div>
  )
}

export default ContactUs
