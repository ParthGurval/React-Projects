import React from 'react'

const Home = () => {
  return (
    <div>
  
    <p>This is Home Page</p>    
      
    </div>
  )
}

export default Home
